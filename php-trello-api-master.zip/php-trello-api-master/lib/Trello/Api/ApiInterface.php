<?php

namespace Trello\Api;

/**
 * Api interface
 */
interface ApiInterface
{
}
