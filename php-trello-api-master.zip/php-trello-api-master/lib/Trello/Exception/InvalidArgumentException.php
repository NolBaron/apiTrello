<?php

namespace Trello\Exception;

/**
 * InvalidArgumentException
 *
 * @author Joseph Bielawski <stloyd@gmail.com>
 */
class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{

}
