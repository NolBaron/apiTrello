<?php

namespace Trello\Exception;

class PermissionDeniedException extends \RuntimeException implements ExceptionInterface
{

}
