<?php

namespace Trello\Exception;

class ApiLimitExceedException extends \InvalidArgumentException implements ExceptionInterface
{

}
