<?php

namespace Trello\Exception;

/**
 * ValidationFailedException
 *
 * @author Joseph Bielawski <stloyd@gmail.com>
 */
class ValidationFailedException extends ErrorException
{

}
