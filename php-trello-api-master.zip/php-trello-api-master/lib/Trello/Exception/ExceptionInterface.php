<?php

namespace Trello\Exception;

interface ExceptionInterface
{

}
