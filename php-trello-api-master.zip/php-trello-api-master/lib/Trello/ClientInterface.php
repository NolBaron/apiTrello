<?php

namespace Trello;

interface ClientInterface
{

}
