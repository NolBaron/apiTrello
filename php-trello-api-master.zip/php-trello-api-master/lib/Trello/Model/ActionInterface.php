<?php

namespace Trello\Model;

interface ActionInterface extends ObjectInterface
{

}
