<?php

namespace Trello\Model;

/**
 * @codeCoverageIgnore
 */
class Action extends AbstractObject implements ActionInterface
{
    protected $apiName = 'action';
}
