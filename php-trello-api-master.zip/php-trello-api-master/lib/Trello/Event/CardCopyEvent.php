<?php

namespace Trello\Event;

class CardCopyEvent extends CardEvent
{
}
