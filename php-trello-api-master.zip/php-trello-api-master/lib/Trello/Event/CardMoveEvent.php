<?php

namespace Trello\Event;

class CardMoveEvent extends CardEvent
{
}
