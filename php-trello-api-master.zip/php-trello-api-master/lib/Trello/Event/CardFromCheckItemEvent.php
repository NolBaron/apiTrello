<?php

namespace Trello\Event;

class CardFromCheckItemEvent extends CardEvent
{
}
