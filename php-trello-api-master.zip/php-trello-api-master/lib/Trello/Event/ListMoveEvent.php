<?php

namespace Trello\Event;

class ListMoveEvent extends ListEvent
{
}
