
======================

### Get identifier
```php
getIdentifier()
```

### Get member id
```php
getMemberId()
```

### Get member
```php
getMember()
```

### {@inheritdoc}
```php
getDateCreated()
```

### {@inheritdoc}
```php
getDateExpires()
```

### Get permissions
```php
getPermissions()
```

### Get webhooks
```php
getWebhooks()
```

