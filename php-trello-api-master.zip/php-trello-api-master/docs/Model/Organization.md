
======================

### Set name
```php
setName($name)
```

### Get name
```php
getName()
```

### Set display name
```php
setDisplayName($displayName)
```

### Get display name
```php
getDisplayName()
```

### Set description
```php
setDescription($desc)
```

### Get desc
```php
getDesciption()
```

### Set description data
```php
setDescriptionData($descData)
```

### Get description data
```php
getDescriptionData()
```

### Set board ids
```php
setBoardIds(array $boardIds)
```

### Get board ids
```php
getBoardIds()
```

### Get boards
```php
getBoards()
```

### Set invited
```php
setInvited(array $invited)
```

### Get invited
```php
getInvited()
```

### Set invitations
```php
setInvitations(array $invitations)
```

### Get invitations
```php
getInvitations()
```

### Get memberships
```php
getMemberships()
```

### {@inheritdoc}
```php
setPrefs(array $prefs)
```

### {@inheritdoc}
```php
getPrefs()
```

### Set power ups
```php
setPowerUps(array $powerUps)
```

### Get power ups
```php
getPowerUps()
```

### Set products
```php
setProducts(array $products)
```

### Get products
```php
getProducts()
```

### Get billable member count
```php
getBillableMemberCount()
```

### Set url
```php
setUrl($url)
```

### Get url
```php
getUrl()
```

### Set website
```php
setWebsite($website)
```

### Get website
```php
getWebsite()
```

### Set logo hash
```php
setLogoHash($logoHash)
```

### Get logo hash
```php
getLogoHash()
```

### Set premium features
```php
setPremiumFeatures(array $premiumFeatures)
```

### Get premium features
```php
getPremiumFeatures()
```

