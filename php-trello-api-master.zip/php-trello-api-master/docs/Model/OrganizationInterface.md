
======================

### Set name
```php
setName(string $name)
```

### Get name
```php
getName()
```

### Set display name
```php
setDisplayName(string $displayName)
```

### Get display name
```php
getDisplayName()
```

### Set description
```php
setDescription(string $desc)
```

### Get desc
```php
getDesciption()
```

### Set description data
```php
setDescriptionData(string $descData)
```

### Get description data
```php
getDescriptionData()
```

### Set board ids
```php
setBoardIds(array $boardIds)
```

### Get board ids
```php
getBoardIds()
```

### Get boards
```php
getBoards()
```

### Set invited
```php
setInvited(string $invited)
```

### Get invited
```php
getInvited()
```

### Set invitations
```php
setInvitations(string $invitations)
```

### Get invitations
```php
getInvitations()
```

### Get memberships
```php
getMemberships()
```

### Set preferences
```php
setPreferences(array $prefs)
```

### Get preferences
```php
getPreferences()
```

### Set power ups
```php
setPowerUps(array $powerUps)
```

### Get power ups
```php
getPowerUps()
```

### Set products
```php
setProducts(array $products)
```

### Get products
```php
getProducts()
```

### Get billable member count
```php
getBillableMemberCount()
```

### Set url
```php
setUrl(string $url)
```

### Get url
```php
getUrl()
```

### Set website
```php
setWebsite(string $website)
```

### Get website
```php
getWebsite()
```

### Set logo hash
```php
setLogoHash(string $logoHash)
```

### Get logo hash
```php
getLogoHash()
```

### Set premium features
```php
setPremiumFeatures(array $premiumFeatures)
```

### Get premium features
```php
getPremiumFeatures()
```

