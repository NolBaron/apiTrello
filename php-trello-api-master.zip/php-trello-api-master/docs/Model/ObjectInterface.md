
======================

### Get identifier
```php
getId()
```

### Save the object through API
```php
save()
```

### Remove the object through API
```php
remove()
```

### Refresh the object through API
```php
refresh()
```

### Get data
```php
getData()
```

### Set data
```php
setData(array $data)
```

