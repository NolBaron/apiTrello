
======================

### Get identifier
```php
getIdentifier()
```

### Get member id
```php
getMemberId()
```

### Get member
```php
getMember()
```

### Get date of creation
```php
getDateOfCreation()
```

### Get date of expiry
```php
getDateOfExpiry()
```

### Get permissions
```php
getPermissions()
```

### Get webhooks
```php
getWebhooks()
```

