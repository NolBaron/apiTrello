
======================

### Set checklist
```php
setChecklist(\Trello\Model\ChecklistInterface $checklist)
```

### Get checklist
```php
getChecklist()
```

