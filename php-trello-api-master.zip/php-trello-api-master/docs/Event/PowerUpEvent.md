
======================

### Set powerUp
```php
setPowerUp(\Trello\Model\PowerUpInterface $powerUp)
```

### Get powerUp
```php
getPowerUp()
```

