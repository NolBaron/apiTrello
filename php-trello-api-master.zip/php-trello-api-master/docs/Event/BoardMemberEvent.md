
======================

### Set member
```php
setMember(\Trello\Model\MemberInterface $member)
```

### Get member
```php
getMember()
```

