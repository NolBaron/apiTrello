
======================

### Set cardlist
```php
setCardlist(\Trello\Model\CardlistInterface $cardlist)
```

### Get cardlist
```php
getCardlist()
```

