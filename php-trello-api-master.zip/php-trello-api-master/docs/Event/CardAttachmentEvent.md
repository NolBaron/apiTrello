
======================

### Set attachment
```php
setAttachment(array $attachment)
```

### Get attachment
```php
getAttachment()
```

