
======================

### Set organization
```php
setOrganization(\Trello\Model\OrganizationInterface $organization)
```

### Get organization
```php
getOrganization()
```

