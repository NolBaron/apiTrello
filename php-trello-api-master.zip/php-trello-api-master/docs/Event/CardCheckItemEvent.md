
======================

### Set checkItem
```php
setCheckItem(\Trello\Model\CheckItemInterface $checkItem)
```

### Get checkItem
```php
getCheckItem()
```

