
======================

### Set board
```php
setBoard(\Trello\Model\BoardInterface $board)
```

### Get board
```php
getBoard()
```

