
======================

### Set comment
```php
setComment(\Trello\Model\CommentInterface $comment)
```

### Get comment
```php
getComment()
```

