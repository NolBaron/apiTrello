
======================

### Set card
```php
setCard(\Trello\Model\CardInterface $card)
```

### Get card
```php
getCard()
```

