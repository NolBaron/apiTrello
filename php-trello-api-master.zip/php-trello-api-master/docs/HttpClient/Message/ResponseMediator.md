
======================

### 
```php
getContent(\Guzzle\Http\Message\Response $response)
```

