
======================

### 
```php
__construct($tokenOrLogin, $password, $method)
```

### 
```php
onRequestBeforeSend(\Guzzle\Common\Event $event)
```

