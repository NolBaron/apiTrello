
======================

### 
```php
__construct(array $options)
```

### {@inheritDoc}
```php
onRequestError(\Guzzle\Common\Event $event)
```

