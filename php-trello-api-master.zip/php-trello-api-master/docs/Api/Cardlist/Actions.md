Trello List Actions API
======================

### Get actions related to a given list
```php
$api->cardlists()->actions()->all(string $id, array $params)
```

