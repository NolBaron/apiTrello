Trello Board Checklists API
======================

### Get cards related to a given board
```php
$api->boards()->checklists()->all(string $id, array $params)
```

### Add an checklist to a given board
```php
$api->boards()->checklists()->create(string $id, array $params)
```

