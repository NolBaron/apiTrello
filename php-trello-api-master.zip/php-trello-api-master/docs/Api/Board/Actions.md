Trello Board Actions API
======================

### Get actions related to a given board
```php
$api->boards()->actions()->all(string $id, array $params)
```

