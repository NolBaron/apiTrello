Trello Member Custom Stickers API
======================

