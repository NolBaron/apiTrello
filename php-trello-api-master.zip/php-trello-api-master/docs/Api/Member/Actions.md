Trello Member Actions API
======================

### Get actions related to a given member
```php
$api->members()->actions()->all(string $id, array $params)
```

