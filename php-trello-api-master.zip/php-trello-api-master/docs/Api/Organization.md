Trello Organization API
======================

### Find an organization by id
```php
$api->organizations()->show(string $id, array $params)
```

