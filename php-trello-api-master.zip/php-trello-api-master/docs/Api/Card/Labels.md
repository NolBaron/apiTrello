Trello Card Labels API
======================

### Set a given card&#039;s labels
```php
$api->cards()->labels()->set(string $id, array $labels)
```

### Remove a given label from a given card
```php
$api->cards()->labels()->remove(string $id, string $label)
```

