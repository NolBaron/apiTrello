MissingArgumentException
======================

### 
```php
__construct($required, $code, $previous)
```

